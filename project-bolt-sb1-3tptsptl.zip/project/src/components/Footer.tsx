import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Logo and Quote */}
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <Logo className="h-10 w-auto mr-4" color="white" />
              <div>
                <h3 className="font-bold text-lg">K Siddhartha Holla</h3>
                <p className="text-gray-400 text-sm">Medical Tutor</p>
              </div>
            </div>
            
            <blockquote className="text-red-400 italic text-lg leading-relaxed mb-4">
              "If you want to learn from the best, money isn't an issue. My sessions are for those who want to achieve top NEET PG/INI-CET ranks and become excellent clinicians."
            </blockquote>
          </div>

          {/* Contact Information */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Contact Information</h4>
            <div className="space-y-3">
              <div className="flex items-center">
                <Phone className="w-5 h-5 mr-3 text-red-400" />
                <span className="text-gray-300">+91 7892583593</span>
              </div>
              <div className="flex items-center">
                <Mail className="w-5 h-5 mr-3 text-red-400" />
                <span className="text-gray-300">ksiddharthholla@gmail.com</span>
              </div>
              <div className="flex items-start">
                <MapPin className="w-5 h-5 mr-3 text-red-400 mt-1" />
                <span className="text-gray-300">
                  Ground floor, Sri Krishna Complex,<br />
                  MG Road, Kodialbail,<br />
                  Mangalore 575003
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-gray-400">
            <strong>Version 2025</strong>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
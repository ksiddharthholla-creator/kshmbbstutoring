import React, { useState } from 'react';
import { X, Calendar, Clock, Upload, CreditCard, Smartphone } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan: '30min' | '1hr' | null;
}

const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, selectedPlan }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    topic: '',
    date: '',
    time: '',
    fmmcId: null as File | null,
    couponCode: '',
    addOn: 'none'
  });
  
  const [showCoupon, setShowCoupon] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'gpay' | null>(null);

  if (!isOpen || !selectedPlan) return null;

  const basePrice = selectedPlan === '30min' ? 2000 : 3500;
  const addOnPrices = { 'none': 0, '30min': 500, '60min': 1000 };
  const totalPrice = basePrice + addOnPrices[formData.addOn as keyof typeof addOnPrices];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission and payment processing
    alert(`Booking submitted! Total: ₹${totalPrice}`);
    onClose();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({ ...prev, fmmcId: file }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-800">Complete Your Booking</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Selected Plan Summary */}
          <div className="bg-red-50 p-4 rounded-xl">
            <h3 className="font-semibold text-red-800 mb-2">Selected Plan</h3>
            <div className="flex justify-between items-center">
              <span className="text-gray-700">
                {selectedPlan === '30min' ? '30 Minutes Session' : '1 Hour Session'}
              </span>
              <span className="font-bold text-red-700">₹{basePrice}</span>
            </div>
          </div>

          {/* Student Information */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-800">Student Information</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Enter your full name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Enter your email for receipt"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Phone / WhatsApp (Optional)
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="+91 XXXXX XXXXX"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Preferred Topic
              </label>
              <input
                type="text"
                value={formData.topic}
                onChange={(e) => setFormData(prev => ({ ...prev, topic: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="e.g., Cardiology, Biochemistry, etc."
              />
            </div>
          </div>

          {/* Scheduling */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-800 flex items-center">
              <Calendar className="w-5 h-5 mr-2" />
              Schedule Session (IST)
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Preferred Date
                </label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Preferred Time
                </label>
                <select
                  value={formData.time}
                  onChange={(e) => setFormData(prev => ({ ...prev, time: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                >
                  <option value="">Select time</option>
                  <option value="18:00">6:00 PM</option>
                  <option value="19:00">7:00 PM</option>
                  <option value="20:00">8:00 PM</option>
                  <option value="21:00">9:00 PM</option>
                  <option value="22:00">10:00 PM</option>
                  <option value="23:00">11:00 PM</option>
                </select>
              </div>
            </div>
            
            <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-xl">
              <strong>Available Hours:</strong><br/>
              Mon-Fri: 6:00 PM - 12:00 AM IST<br/>
              Sunday: 10:00 AM - 11:00 PM IST<br/>
              Saturday: Unavailable
            </div>
          </div>

          {/* Add-ons (only for 1hr sessions) */}
          {selectedPlan === '1hr' && (
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-800">Add-ons</h3>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="addon"
                    value="none"
                    checked={formData.addOn === 'none'}
                    onChange={(e) => setFormData(prev => ({ ...prev, addOn: e.target.value }))}
                    className="mr-3"
                  />
                  <span>No add-on</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="addon"
                    value="30min"
                    checked={formData.addOn === '30min'}
                    onChange={(e) => setFormData(prev => ({ ...prev, addOn: e.target.value }))}
                    className="mr-3"
                  />
                  <span>+30 minutes → ₹500</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="addon"
                    value="60min"
                    checked={formData.addOn === '60min'}
                    onChange={(e) => setFormData(prev => ({ ...prev, addOn: e.target.value }))}
                    className="mr-3"
                  />
                  <span>+60 minutes → ₹1000</span>
                </label>
              </div>
            </div>
          )}

          {/* Coupon Section */}
          <div className="space-y-4">
            <button
              type="button"
              onClick={() => setShowCoupon(!showCoupon)}
              className="text-red-700 hover:text-red-800 font-medium"
            >
              Have a Father Muller discount code? (Only for FMMC students)
            </button>
            
            {showCoupon && (
              <div className="space-y-4 bg-gray-50 p-4 rounded-xl">
                <div>
                  <input
                    type="text"
                    value={formData.couponCode}
                    onChange={(e) => setFormData(prev => ({ ...prev, couponCode: e.target.value }))}
                    placeholder="Enter coupon code"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Upload FMMC ID (JPG/PNG/PDF)
                  </label>
                  <div className="flex items-center space-x-4">
                    <label className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-xl cursor-pointer hover:bg-gray-50">
                      <Upload className="w-5 h-5 mr-2 text-gray-500" />
                      <span className="text-sm text-gray-700">Choose file</span>
                      <input
                        type="file"
                        accept=".jpg,.jpeg,.png,.pdf"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                    {formData.fmmcId && (
                      <span className="text-sm text-green-600">{formData.fmmcId.name}</span>
                    )}
                  </div>
                </div>
                
                <p className="text-sm text-red-600">
                  <strong>Only applicable to FMMC students.</strong>
                </p>
              </div>
            )}
          </div>

          {/* Payment Methods */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-800">Payment Method</h3>
            
            <div className="grid gap-4">
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`p-4 border-2 rounded-xl flex items-center justify-between transition-colors ${
                  paymentMethod === 'card' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center">
                  <CreditCard className="w-6 h-6 mr-3 text-gray-600" />
                  <span className="font-medium">Credit / Debit Card</span>
                </div>
                <span className="text-sm text-gray-500">Secure payment</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('paypal')}
                className={`p-4 border-2 rounded-xl flex items-center justify-between transition-colors ${
                  paymentMethod === 'paypal' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center">
                  <div className="w-6 h-6 mr-3 bg-blue-600 rounded text-white text-xs flex items-center justify-center font-bold">
                    P
                  </div>
                  <span className="font-medium">PayPal</span>
                </div>
                <span className="text-sm text-gray-500">paypal.me/ksh2002</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('gpay')}
                className={`p-4 border-2 rounded-xl flex items-center justify-between transition-colors ${
                  paymentMethod === 'gpay' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center">
                  <Smartphone className="w-6 h-6 mr-3 text-gray-600" />
                  <span className="font-medium">Google Pay / UPI</span>
                </div>
                <span className="text-sm text-gray-500">QR Code</span>
              </button>
            </div>

            {paymentMethod === 'gpay' && (
              <div className="bg-gray-50 p-4 rounded-xl text-center">
                <img 
                  src="/assets/GooglePay_QR.png" 
                  alt="Google Pay QR Code" 
                  className="mx-auto mb-4 max-w-48 h-auto"
                />
                <p className="text-sm text-gray-600">Scan QR code to pay via Google Pay or any UPI app</p>
              </div>
            )}
          </div>

          {/* Total */}
          <div className="bg-gray-50 p-4 rounded-xl">
            <div className="flex justify-between items-center text-lg font-bold">
              <span>Total Amount:</span>
              <span className="text-red-700">₹{totalPrice}</span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-red-700 text-white py-4 rounded-2xl font-semibold hover:bg-red-800 transition-colors duration-300 text-lg"
          >
            Complete Booking - ₹{totalPrice}
          </button>

          <p className="text-xs text-gray-500 text-center">
            Secure payment — receipt & confirmation email sent instantly.
          </p>
        </form>
      </div>
    </div>
  );
};

export default BookingModal;
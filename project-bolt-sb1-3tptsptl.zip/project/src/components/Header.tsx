import React from 'react';
import Logo from './Logo';

interface HeaderProps {
  onNavigate: (section: string) => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
  return (
    <header className="bg-red-700 text-white sticky top-0 z-50 shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Logo className="h-12 w-auto" color="white" />
            <div>
              <h1 className="text-xl font-bold">K Siddhartha Holla</h1>
              <p className="text-sm opacity-90">MBBS Intern & Medical Tutor</p>
              <p className="text-xs opacity-75">Father Muller Medical College</p>
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-6">
            <button 
              onClick={() => onNavigate('booking')}
              className="hover:text-red-200 transition-colors font-medium"
            >
              Book
            </button>
            <button 
              onClick={() => onNavigate('faqs')}
              className="hover:text-red-200 transition-colors font-medium"
            >
              FAQs
            </button>
            <button 
              onClick={() => onNavigate('contact')}
              className="hover:text-red-200 transition-colors font-medium"
            >
              Contact
            </button>
          </nav>

          {/* Mobile menu button */}
          <button className="md:hidden">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
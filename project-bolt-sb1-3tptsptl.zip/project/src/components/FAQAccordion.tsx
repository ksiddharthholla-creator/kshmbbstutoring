import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQAccordion: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "What topics can I book?",
      answer: "Any MBBS subject (pre-clinical, para-clinical, clinical). Prior intimation required."
    },
    {
      question: "Is topic understanding guaranteed?",
      answer: "Yes — sessions focus on clarity and practical problem solving. If you still have doubts, I will re-explain until you understand."
    },
    {
      question: "What if my session doesn't happen?",
      answer: "100% refund if a session is not conducted."
    },
    {
      question: "Can I extend a session?",
      answer: "Yes — add-ons are available during checkout for 1-hour buyers only."
    },
    {
      question: "How are sessions conducted?",
      answer: "All sessions are on Zoom. Links are shared after booking."
    },
    {
      question: "Will I get study material?",
      answer: "Yes — practice questions are provided after the session."
    },
    {
      question: "Why should I buy now?",
      answer: "Prices are low now — as demand grows, prices will rise. Investing in effective tutoring now can change your rank and help you get into your dream college and career. Treat this as an investment in your future."
    },
    {
      question: "What will I learn?",
      answer: "High-yield MCQ solving strategies and techniques that have worked repeatedly in the toughest exams — targeted methods to break down and solve difficult questions efficiently."
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-16 bg-gray-50" id="faqs">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">
          Frequently Asked Questions
        </h2>
        
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
                aria-expanded={openIndex === index}
                aria-controls={`faq-answer-${index}`}
              >
                <h3 className="font-semibold text-gray-800 pr-4">{faq.question}</h3>
                {openIndex === index ? (
                  <ChevronUp className="w-5 h-5 text-red-700 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-red-700 flex-shrink-0" />
                )}
              </button>
              
              {openIndex === index && (
                <div 
                  id={`faq-answer-${index}`}
                  className="px-6 pb-4 text-gray-700 leading-relaxed"
                  role="region"
                  aria-labelledby={`faq-question-${index}`}
                >
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQAccordion;
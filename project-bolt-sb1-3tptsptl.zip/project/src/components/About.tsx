import React from 'react';
import { Award, BookOpen, Users } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-8 text-center">
            About Me
          </h2>
          
          <div className="bg-gray-50 rounded-2xl p-8 mb-12 shadow-lg">
            <p className="text-lg text-gray-700 leading-relaxed">
              I am currently an MBBS intern at Father Muller Medical College. I simplify complex medical concepts into easy-to-understand lessons. I have topped Biochemistry, won multiple quizzes, contributed to QBank development, and guided many students successfully.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-red-700" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Top Performer</h3>
              <p className="text-gray-600 text-sm">Topped Biochemistry & won multiple medical quizzes</p>
            </div>
            
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-red-700" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">QBank Developer</h3>
              <p className="text-gray-600 text-sm">Contributed to medical question bank development</p>
            </div>
            
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-red-700" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Proven Mentor</h3>
              <p className="text-gray-600 text-sm">Successfully guided many students to success</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
import React from 'react';

interface BannerProps {
  onBooking: (duration: '30min' | '1hr') => void;
}

const Banner: React.FC<BannerProps> = ({ onBooking }) => {
  return (
    <section className="relative h-96 md:h-[500px] overflow-hidden">
      <div className="absolute inset-0">
        <img 
          src="/assets/1000090333.jpg" 
          alt="Medical tutoring session" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      </div>
      
      <div className="relative z-10 h-full flex items-center justify-center text-center text-white px-4">
        <div className="max-w-4xl">
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            One-to-One Medical Tutoring
          </h2>
          <p className="text-xl md:text-2xl mb-8 italic">
            NEET PG & INI-CET Guidance
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => onBooking('30min')}
              className="px-8 py-3 border-2 border-white text-white hover:bg-white hover:text-red-700 transition-all duration-300 rounded-2xl font-semibold"
            >
              Book 30-min
            </button>
            <button 
              onClick={() => onBooking('1hr')}
              className="px-8 py-3 bg-red-700 text-white hover:bg-red-800 transition-all duration-300 rounded-2xl font-semibold shadow-lg"
            >
              Book 1-hr
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Banner;
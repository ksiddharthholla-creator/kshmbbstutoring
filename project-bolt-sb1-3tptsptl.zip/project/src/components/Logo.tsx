import React from 'react';

interface LogoProps {
  className?: string;
  color?: string;
  variant?: 'full' | 'icon';
}

const Logo: React.FC<LogoProps> = ({ 
  className = "h-10 w-auto", 
  color = "#C62828",
  variant = "full" 
}) => {
  if (variant === "icon") {
    return (
      <svg className={className} viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g>
          {/* K */}
          <path d="M8 10 L8 50 M8 30 L25 10 M8 30 L25 50" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
          {/* S with stethoscope curve */}
          <path d="M35 20 Q30 15 25 20 Q30 25 35 20 Q40 15 45 20 Q40 25 35 30 Q40 35 45 30 Q40 25 35 30" stroke={color} strokeWidth="3" strokeLinecap="round" fill="none"/>
          {/* H as book spine */}
          <path d="M50 10 L50 50 M50 30 L58 30 M58 10 L58 50" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
          {/* Stethoscope detail */}
          <circle cx="45" cy="15" r="2" fill={color}/>
        </g>
      </svg>
    );
  }

  return (
    <svg className={className} viewBox="0 0 200 60" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g>
        {/* K */}
        <path d="M15 10 L15 50 M15 30 L35 10 M15 30 L35 50" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
        {/* S with stethoscope curve */}
        <path d="M55 20 Q50 15 45 20 Q50 25 55 20 Q60 15 65 20 Q60 25 55 30 Q60 35 65 30 Q60 25 55 30" stroke={color} strokeWidth="3" strokeLinecap="round" fill="none"/>
        {/* H as book spine */}
        <path d="M85 10 L85 50 M85 30 L95 30 M95 10 L95 50" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
        {/* Stethoscope detail */}
        <circle cx="65" cy="15" r="2" fill={color}/>
        {/* Medical text */}
        <text x="110" y="25" fill={color} fontSize="12" fontWeight="600" fontFamily="system-ui">MEDICAL</text>
        <text x="110" y="40" fill={color} fontSize="12" fontWeight="600" fontFamily="system-ui">TUTOR</text>
      </g>
    </svg>
  );
};

export default Logo;
import React, { useState } from 'react';
import Header from './components/Header';
import Banner from './components/Banner';
import About from './components/About';
import Testimonials from './components/Testimonials';
import PricingCards from './components/PricingCards';
import BookingModal from './components/BookingModal';
import FAQAccordion from './components/FAQAccordion';
import Footer from './components/Footer';

function App() {
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'30min' | '1hr' | null>(null);

  const handleBooking = (duration: '30min' | '1hr') => {
    setSelectedPlan(duration);
    setIsBookingModalOpen(true);
  };

  const handleNavigate = (section: string) => {
    if (section === 'booking') {
      document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
    } else if (section === 'faqs') {
      document.getElementById('faqs')?.scrollIntoView({ behavior: 'smooth' });
    } else if (section === 'contact') {
      document.querySelector('footer')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header onNavigate={handleNavigate} />
      <Banner onBooking={handleBooking} />
      <About />
      <Testimonials />
      <div id="pricing">
        <PricingCards onSelectPlan={handleBooking} />
      </div>
      <FAQAccordion />
      <Footer />
      
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        selectedPlan={selectedPlan}
      />
    </div>
  );
}

export default App;
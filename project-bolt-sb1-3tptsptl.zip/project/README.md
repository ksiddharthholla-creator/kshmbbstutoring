# K Siddhartha Holla - Medical Tutoring Website

A production-ready React application for medical tutoring services, built with React, TypeScript, and Tailwind CSS.

## Features

- **Responsive Design**: Mobile-first approach with beautiful UI
- **Booking System**: Complete booking flow with payment integration
- **Pricing Plans**: 30-minute and 1-hour tutoring sessions
- **FAQ Accordion**: Comprehensive answers to common questions
- **Testimonials**: Student feedback and reviews
- **Payment Integration**: Multiple payment options (Card, PayPal, Google Pay)
- **Coupon System**: Special discounts for FMMC students
- **Email Confirmations**: Automated booking confirmations

## Asset Management

This project uses the **public folder approach** for static assets. All images should be placed in the `public/assets/` directory.

### Required Assets

Place these files in `public/assets/`:

1. `1000090333.jpg` - Mentoring photo for the hero banner
2. `GooglePay_QR.png` - QR code for Google Pay payments

### Usage in Components

```jsx
// Correct way to reference assets
<img src="/assets/1000090333.jpg" alt="Mentoring photo" />
<img src="/assets/GooglePay_QR.png" alt="Google Pay QR Code" />
```

The leading slash (`/`) ensures the assets are loaded from the public directory at runtime.

## Getting Started

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Add Required Assets**
   - Create `public/assets/` directory
   - Add `1000090333.jpg` and `GooglePay_QR.png` to this directory

3. **Start Development Server**
   ```bash
   npm run dev
   ```

4. **Build for Production**
   ```bash
   npm run build
   ```

## Project Structure

```
src/
├── components/
│   ├── Header.tsx          # Navigation header
│   ├── Banner.tsx          # Hero section with CTA
│   ├── About.tsx           # About section
│   ├── Testimonials.tsx    # Student testimonials
│   ├── PricingCards.tsx    # Pricing plans
│   ├── BookingModal.tsx    # Booking form and payment
│   ├── FAQAccordion.tsx    # FAQ section
│   ├── Footer.tsx          # Footer with contact info
│   └── Logo.tsx            # Custom SVG logo component
├── App.tsx                 # Main application component
├── main.tsx               # Application entry point
└── index.css              # Tailwind CSS imports
```

## Key Features

### Booking System
- **30-minute sessions**: ₹2,000 for quick concept clarity
- **1-hour sessions**: ₹3,500 for comprehensive tutoring
- **Add-ons**: Available for 1-hour sessions (+30min/+60min)
- **Scheduling**: Mon-Fri 6PM-12AM, Sunday 10AM-11PM (Saturday unavailable)

### Payment Integration
- **Credit/Debit Cards**: Stripe integration ready
- **PayPal**: Direct link to paypal.me/ksh2002
- **Google Pay/UPI**: QR code for instant payments

### Coupon System
- **MUKULLORD10**: Special discount for FMMC students
- **ID Verification**: Upload FMMC ID for validation
- **Manual Approval**: Admin verification required

### Email Confirmations
Automated emails sent to both student and tutor with:
- Session details and Zoom links
- Payment confirmation
- Study material information
- Contact details

## Customization

### Colors
- **Primary Red**: `#C62828`
- **Text**: `#1F2937`
- **Background**: White with gray accents

### Typography
- System fonts with Inter fallback
- Responsive text sizing
- Proper contrast ratios for accessibility

### Logo
Custom SVG logo with two variants:
- **Full**: Text + icon for desktop
- **Icon**: Compact version for mobile

## Deployment

This project is ready for deployment to any static hosting service:

1. **Build the project**: `npm run build`
2. **Upload the `dist` folder** to your hosting service
3. **Ensure assets are accessible** at `/assets/` path
4. **Configure environment variables** for payment processing

## Environment Variables

For production deployment, configure:

```env
VITE_STRIPE_PUBLIC_KEY=your_stripe_public_key
VITE_PAYPAL_CLIENT_ID=your_paypal_client_id
VITE_EMAIL_SERVICE_ID=your_email_service_id
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

Private project for K Siddhartha Holla Medical Tutoring Services.